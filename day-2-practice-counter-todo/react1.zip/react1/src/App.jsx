
import './App.css'
import Counter from './component/counter/Counter'
import Todo from './component/todo/Todo'

function App() {
  

  return (
    <>
    <Counter/>
    <Todo/>
    
    </>
  )
}

export default App
